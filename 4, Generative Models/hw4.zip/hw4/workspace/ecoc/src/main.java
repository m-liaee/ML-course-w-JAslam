import java.beans.FeatureDescriptor;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class main {
	
	public static void main(String[] args) {
		
		String train_file = "8newsgroup//train.trec//feature_matrix.txt"; 
		String test_file = "8newsgroup//test.trec//feature_matrix.txt"; 
		
		String dcs_file = "dc_stumps.txt"; 
		
		int train_size = 11314;
		int test_size = 7532; 
		
		int num_features = 1754; 
		
		int num_labels = 8; 
		int num_functions = 10; // 20 
		int distance = 3; // 10 
		
		int T = 100; 
		boolean is_random_decision = true; 
		
		Parser p_1 = new Parser(train_file,num_features);
		p_1.Parse_n_line(train_size);
		double[][] train_data = p_1.features_vals;
		int [] train_y = p_1.label_vals; 
		
	
		/**		
		Parser p_2 = new Parser(test_file, num_features);
		p_2.Parse_n_line(test_size); 
		double[][] test_data = p_2.features_vals;
		int [] test_y = p_2.label_vals;
		/**/		
		
		ArrayList<Decision_Stump> dcs = Decision_Stump.getDecisionStumps(train_data,num_features);
		Decision_Stump.WriteDCstumpsToFile(dcs_file, dcs); 
		//ArrayList<Decision_Stump> dcs = Decision_Stump.ReadDCstumpsFromFile(dcs_file);
		System.out.println("Decision Stumps are created.");
		
		
//		Ecoc ecoc = new Ecoc(distance, num_functions, num_labels);
//		ArrayList<Model> models = ecoc.Train(train_data, train_y, dcs, is_random_decision, T);
//
//		ecoc.Test(train_data, train_y, models);
//		
//		//ecoc.Test(test_data, test_y, models);
		
	
	
	}
}
