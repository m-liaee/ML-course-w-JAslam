import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;


public class Decision_Stump {
	int feature_id; 
	double threshold; 
	double prob; 
	
	public Decision_Stump(int f_id, double thresh , double prob) {
			feature_id = f_id; 
			threshold = thresh; 
			this.prob = prob; 
	}
	
	public String toString() {
		String s = "feature id: " + feature_id + " threshold: "+threshold + " probability: "+prob;
		return s; 
	}
	
	public static ArrayList<Decision_Stump> getDecisionStumps(double [][] data , int feature_num ){
		
		int diff = 2; // get 0.1 of the decision stumps
		//int num_col = data[0].length;
		int num_col = feature_num; 
		double epsilon = 0.1; 
		
		ArrayList<Decision_Stump> dcs = new ArrayList<Decision_Stump>(); 
		
		for (int j = 0 ; j < num_col ; j++){
			
			System.out.println("feature " + j);
			double [] col_j = Util.getTableColumn_j(data, j);
			col_j = Util.SortVal(col_j);
			ArrayList<Double> uniq_vals = Util.FindUniqueVal(col_j); 
			
			if (uniq_vals.size() > 0){
				double t = uniq_vals.get(0); 
				
				Decision_Stump dc; 
//				dc = new Decision_Stump(j, t-epsilon);				
//				dcs.add(dc);
				
				for (int k = 0 ; k +diff < uniq_vals.size()-1; k = k+diff ){
					double t_1 = uniq_vals.get(k);
					double t_2 = uniq_vals.get(k+diff);
					
					double thresh = (t_1 + t_2)/2; 
					double prob = getProbLessThresh(data, j, thresh);
					dc = new Decision_Stump(j, thresh, prob );
					
					dcs.add(dc); 
				}
				
				t = uniq_vals.get(uniq_vals.size()-1);
				
				double thresh = t+epsilon; 
				double prob = getProbLessThresh(data, j, thresh);
				dc = new  Decision_Stump(j, thresh, prob);
				dcs.add(dc); 
				
			}
			System.out.println(dcs.size());
	
		}
		return dcs; 
		
	}
	
	public static void WriteDCstumpsToFile(String file_addr, ArrayList<Decision_Stump> dcs){
		
		PrintWriter writer;
		try {
			writer = new PrintWriter(file_addr, "UTF-8");
			int len = dcs.size(); 
			for(int i = 0 ; i < len ; i++){
				String s = dcs.get(i).feature_id+":"+dcs.get(i).threshold+":"+dcs.get(i).prob; 
				writer.println(s); 
			}
			writer.close();
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {

			e.printStackTrace();
		}
		
		
		
	}
	
	public static ArrayList<Decision_Stump> ReadDCstumpsFromFile(String file_addr){
		ArrayList<Decision_Stump> dcs = new ArrayList<Decision_Stump>(); 
		try {
			FileInputStream fstream;
			fstream = new FileInputStream(file_addr);
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			
			String strLine; 
			try {
				while ((strLine = br.readLine()) != null){
					strLine = strLine.trim();
					String[] tokens = strLine.split(":");
					int f_id = Integer.parseInt(tokens[0]); 
					double thresh = Double.parseDouble(tokens[1]);
					double prob = Double.parseDouble(tokens[2]);
					Decision_Stump dc = new Decision_Stump(f_id,thresh,prob); 
					dcs.add(dc);
					
				}
			} catch (IOException e) {
			
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
			
			
		
	
		
		return dcs; 
	}
	
	public static double getProbLessThresh(double [][] data, int f_id, double thresh){
		int len = data.length; 
		int count_has_value = 0;  
		int count_less_thresh = 0; 
		
		for (int i = 0 ; i < len; i++){
			if (data[i][f_id] != 0){
				count_has_value++; 
				if (data[i][f_id] < thresh)
					count_less_thresh++; 
			}
		}
		return count_less_thresh/((double) count_has_value );
	}
}
