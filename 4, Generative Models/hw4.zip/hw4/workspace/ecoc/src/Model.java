import java.util.ArrayList;


public class Model {
	ArrayList<Decision_Stump> dcs; 
	ArrayList<Double> alphas;
	
	
	public Model() {
		dcs = new ArrayList<Decision_Stump>(); 
		alphas = new ArrayList<Double>(); 
	 
	}
}
