import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;


public class test {
	public static void main(String[] args) {
		double eps = 5.3884810841347175; 
		double alpha = (double)1/2 * Math.log( eps);
		
		System.out.println(alpha);

	}
}
