import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;


public class Parser {
	
	int features_num; 
	double[][] features_vals; 
	int[] label_vals; 
	String file_addr ;
	

	public Parser(String file_addr, int features_num){
		this.file_addr = file_addr; 
		this.features_num = features_num; 
	}
	
	public void Parse_n_line (int n){
		try {
			FileInputStream fstream;
			fstream = new FileInputStream(file_addr);
			BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
			int counter = 0 ;
			
			features_vals = Util.createDouble_Matrix(n, features_num);
			label_vals = new int [n]; 
			
			try {
				while(counter < n){
					String str_line = br.readLine();
					String[] tokens = str_line.split("[ ]+");
					
					label_vals[counter] = Integer.parseInt(tokens[0]);
					//System.out.println(label_vals[counter]);
					
					for (int i = 1 ; i < tokens.length; i++){
						tokens[i] = tokens[i].trim();
						String[] temp = tokens[i].split(":");
						int f_index = Integer.parseInt(temp[0]);
						double f_value = Double.parseDouble(temp[1]);
						
						features_vals[counter][f_index] = f_value; 
					}
					           
					counter ++; 
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	
}
