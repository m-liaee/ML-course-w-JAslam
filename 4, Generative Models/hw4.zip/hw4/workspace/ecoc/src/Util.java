import java.util.ArrayList;
import java.util.Random;


public class Util {

	// checked :D 
	public static int[][] getTableWithHamingDistance(int distance, int num_row, int num_col){
		int [][] haming_table  = new int [num_row][];
		
		for (int i = 0 ; i < num_row ; i++){
			haming_table[i] = new int [num_col]; 
		}
		
		Random randomGenerator = new Random();
		int max_int = (int)Math.pow(2, num_col); 
		 
		for (int i = 0 ; i < num_row; i++){
			boolean generated = false;
			while (! generated){	    
				int random_int = randomGenerator.nextInt(max_int);
				int [] temp = getBinaryArray(random_int, num_col);
				boolean new_entry_is_good = hasSufficientDistance(distance, haming_table, temp, i);
				if (new_entry_is_good){
					generated = true;
					haming_table[i] = temp; 
				}
			}
			
			System.out.println("Haming row# "+i+" is created." );			
		}
		
		return haming_table; 
	}
	
	// checked
	public static int getDistance(int a[], int b[]){
		int sum = 0; 
		
		int len = a.length; 
		
		for (int i = 0 ; i < len ; i++){
			if (a[i] != b[i])
				sum++; 
		}
		
		return sum; 
	}
	
	// checked
	public static int[] getBinaryArray(int n, int length){
		int [] arr = new int [length]; 
		for (int i = length-1 ; i >= 0 ; i--){
			arr[i] = n % 2;
			n = n/2; 
		}
		return arr; 
	}
	
	public static boolean hasSufficientDistance(int distance, int [][] table, int[] temp, int j){
		 
		for (int i = 0 ; i < j; i++){
			int d = getDistance(table[i], temp);
			if (d < distance)
				return false; 
		}
		
		return true; 
	}
	
	public static int[] getTableColumn_j(int[][] table, int j ){
		int row_num = table.length; 
		int col_num = table[0].length; 
		
		if ( j>= col_num){
			System.err.println("function Util.getTableColumn_j: j exceeds table cols");
			return null; 
		}
		
		int[] col_arr = new int[row_num];
		for(int i = 0 ; i < row_num; i++){
			col_arr[i] = table[i][j];
		}
		
		return col_arr; 
	}
	
	public static int[] getTableRow_i(int[][]table, int i){
		int row_num = table.length; 
		int col_num = table[0].length;
		
		if (i>= row_num ){
			System.err.println("function Util.getTableRow_i: i exceeds table rows");
			return null; 
		}
		
		int[] row_arr = new int[col_num]; 
		for (int k = 0 ; k < col_num; k++){
			row_arr[k] = table[i][k];
		}
		return row_arr; 
	}
	
	

	public static double[] getTableColumn_j(double[][] table, int j ){
		int row_num = table.length; 
		int col_num = table[0].length; 
		
		if ( j>= col_num){
			System.err.println("function Util.getTableColumn_j: j exceeds table cols");
			return null; 
		}
		
		double[] col_arr = new double[row_num];
		for(int i = 0 ; i < row_num; i++){
			col_arr[i] = table[i][j];
		}
		
		return col_arr; 
	}
	
	public static double[] getTableRow_i(double[][]table, int i){
		int row_num = table.length; 
		int col_num = table[0].length;
		
		if (i>= row_num ){
			System.err.println("function Util.getTableRow_i: i exceeds table rows");
			return null; 
		}
		
		double[] row_arr = new double[col_num]; 
		for (int k = 0 ; k < col_num; k++){
			row_arr[k] = table[i][k];
		}
		return row_arr; 
	}
	
	public static ArrayList<Double> FindUniqueVal(double array[]){
		
		double[] tmp; 		
		tmp = SortVal(array);
		int size = tmp.length; 
		
		ArrayList<Double> uniq_val = new ArrayList<Double>();
		
		uniq_val.add(tmp[0]); 
		for (int i = 1 ; i < size ; i++){
			if (tmp[i] - tmp[i-1] > 0)
				uniq_val.add(tmp[i]); 
				
		}		
		return uniq_val; 
		
		
	}
	
	
	public static double[] SortVal(double array[]){
		
		double[] tmp = new double [array.length]; 
		
		for (int i = 0 ; i < array.length ; i++){
			tmp[i] = array[i]; 			
		}
		
		//simple sort 
		for (int i = 0 ; i < tmp.length -1 ; i++){
			for (int j = i +1 ; j < tmp.length ; j++){
				
				//swap
				if ( tmp[i] > tmp[j]){
					double t ; 
					t = tmp[j]; 
					tmp[j] = tmp[i]; 
					tmp[i] = t; 
				}
					
			}
		}
		
		
		return tmp; 
	}
	
	public static double [][] createDouble_Matrix(int row, int col){
		double[][] matrix = new double[row][]; 
		for (int i = 0 ; i < row; i++){
			matrix[i] = new double[col];
			for (int j = 0 ; j < col ; j++)
				matrix[i][j] = 0; 
		}
		return matrix; 
	}
	
	public static double[] GetUniformDistribution(int n) {
		double [] dist = new double[n];
		
		for (int i = 0 ; i < n ; i++){
			dist[i] = (double)1/n; 
		}
		return dist;
	}
	
	public static double getError(double[] distribution, int[] predicted_val, int[] y ){
		int len = distribution.length; 
		
		double sum = 0; 
		for (int i = 0 ; i < len ; i++){
			if( predicted_val[i] != y[i]){
				sum = sum + distribution[i];
			}
		}
		
		return sum; 
	}
	public static void print(int [] a){
		int len = a.length;
		String s = ""; 
		for (int i = 0 ; i < len; i++)
				s = s + ","+a[i]; 
		System.out.println(s);
	}
	
	public static void print(int [][] a ){
		int row = a.length; 
		int col = a[0].length; 
		
		
		for (int i = 0 ; i < row ; i++){
			String s = ""; 
			for (int j = 0 ; j < col ; j++)
				s = s + "," + a[i][j];
			System.out.println(s);
		}
	}
	public static  double[][] getSubMatrix(double [][] matrix , int row , int col){
		double [][] sub_matrix = new double [row][col];
		
		for (int i = 0 ; i < row; i++)
			for(int j = 0 ; j < col ; j++)
				sub_matrix[i][j] = matrix[i][j];
		return sub_matrix; 
		
	}
	
	public static int[] getSubArray(int [] arr , int sub_inx){
		int [] sub_arr = new int [sub_inx];
		for (int i = 0 ; i < sub_inx; i++)
			sub_arr[i] = arr[i];
		
		return sub_arr; 
	}
	
	public static int getBiasedCoid(double pr){
		double d = Math.random(); 
		if (d<pr)
			return 0; 
		else 
			return 1; 
	}
}
