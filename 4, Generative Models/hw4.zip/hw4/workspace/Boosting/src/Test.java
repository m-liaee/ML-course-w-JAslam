import java.util.ArrayList;
import java.util.Random;


public class Test {
	public static void main(String[] args) {
		Parser p = new Parser("crx.config", "crx.data");
		
//		AdaBoost ada = new AdaBoost(p.features, p.labels);
//		ArrayList<DataPoint> data = new ArrayList<DataPoint>(); 
//		data.add(p.datapoints.get(0));
//		data.add(p.datapoints.get(1));
//		data.add(p.datapoints.get(2));
//		data.add(p.datapoints.get(3));
//		data.add(p.datapoints.get(4));
//		
//		Decision_Stump dc_stump = new Decision_Stump(); 
//		dc_stump.feature_id = 0; 
//		dc_stump.threshold_val = "a"; 
//		ArrayList<Character> pre = ada.getPrediction(dc_stump, data);
//		
//		System.out.println(pre.get(0));
//		System.out.println(pre.get(1));
//		System.out.println(pre.get(2));
//		System.out.println(pre.get(3));
//		System.out.println(pre.get(4));
		
		

	}
}
