
public class Model {

	double alpha; 
	Decision_Stump decision_stump; 
}
