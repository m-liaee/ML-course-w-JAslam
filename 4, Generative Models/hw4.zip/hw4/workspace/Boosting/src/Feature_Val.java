
public class Feature_Val {
	int featur_id ; 
	String value; 
}
