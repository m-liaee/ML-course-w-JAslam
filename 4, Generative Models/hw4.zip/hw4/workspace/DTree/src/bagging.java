import java.util.ArrayList;

import javax.sql.rowset.Predicate;


public class bagging {
	
	public static void main(String[] args) {
		
		//read data
		float[][] data = FileReading.ReadFile("spambase.data");
		System.out.println("");
				
		int n = data.length; 
		int m = data[0].length; 
		
		boolean isClassification = true;
		boolean hasLimitedLevel = true;
		
		ArrayList<Float> labels_list = null;
		if (isClassification){
			float [] labels = new float[n]; 			
			for (int j = 0 ; j < n ; j++)
				labels[j]= data[j][m-1];
			
			labels_list = Util.FindUniqueVal(labels); 
			
		}
		
		int T = 50;		
		int k = 10;
		float level = 4; 		
		
		// k fold cross validation
		for(int i = 1 ; i < 2 ; i++){
			System.out.println("folder #"+i+"\n");
			
			float [][] train = Util.split_train_data(data,i,k);
			float [][] test = Util.split_test_data(data,i,k);
			
			ArrayList<Tree> model = new ArrayList<Tree>(); 
			int sample_num = train.length;
			
			// training time
			for (int t = 1; t < T+1; t++ ){
								 
				float [][] sample_train = Util.sample_with_replacement(train, sample_num); 
				System.out.println("train data #"+t+" is sampled with replacement.");
				int train_size = sample_train.length; 
				
				ArrayList<Feature> features_list = Feature.ExtractFeatures(sample_train, train_size, m-1);
					
				Tree tree = new Tree(sample_train, features_list, isClassification , hasLimitedLevel , level);
				tree.createTree(labels_list);
				System.out.println("Tree #"+t+" is trained. \n");
				
				model.add(tree);
				
			}
			
			/**/
			//train performance
			float [] train_predicted_vals = prediction(model,train);
			
			float [] train_y = Util.get_column(train,m-1); 
			int train_num_accurate = Util.count_equivalance(train_predicted_vals, train_y);
			int train_size = train.length; 
			float train_acc_rate = (float)train_num_accurate/train_size;
			float train_err_rate = 1 - train_acc_rate; 
			System.out.println("train:: accuracy rate: " + train_acc_rate +  " error rate" + train_err_rate);
			
			/**/
			/**/
			
			// test performance
			float [] test_predicted_vals = prediction(model, test);
			float [] test_y = Util.get_column(test,m-1);
						
			int test_num_accurate = Util.count_equivalance(test_predicted_vals, test_y);
			int test_size = test.length; 
			float test_acc_rate = (float)test_num_accurate/test_size;
			float test_err_rate = 1 - test_acc_rate; 
			System.out.println("test:: accuracy rate: " + test_acc_rate + " error rate" + test_err_rate);
						
			/**/
			
		}
			
	}
	
	public static float[] prediction(ArrayList<Tree> model, float [][] data){
	
		int n = data.length; 
		float [] predicted_val = new float[n]; 
		
		// prediction for each point
		for (int i = 0 ; i < n ; i++){
			int count_spam_guess = 0; 
			int count_nonspam_guess = 0; 
			
			int T = model.size(); 
			for (int t = 0; t < T; t++){
				Tree tree = model.get(t); 
				float pre_val = tree.FindPredictedValue(data[i]);
				
				if( pre_val == 0 ){
					count_nonspam_guess ++; 
				}else{
					count_spam_guess ++; 
				}					
			}
			
			//take the majority
			if (count_spam_guess > count_nonspam_guess ){
				predicted_val[i] = 1; 
			
			}else{
				predicted_val[i] = 0;
			}
		}
		
		return predicted_val; 
	}
}
