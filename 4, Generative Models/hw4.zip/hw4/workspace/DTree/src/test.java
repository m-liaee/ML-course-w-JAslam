
public class test {

	public static void main(String[] args){
		
		float [][] d = new float [3][4]; 
		 
		d[0][0] = 2;
		d[0][1] = 4;
		d[0][2] = 10;
		d[0][3] = 1;
		d[1][0] = 5;
		d[1][1] = 2;
		d[1][2] = 7;
		d[1][3] = 1;
		d[2][0] = 3;
		d[2][1] = 8;
		d[2][2] = 5;
		d[2][3] = -1;
		
		float [][] sample_d = Util.sample_with_replacement(d, 2);
		
		
		for (int i = 0 ; i < 2; i++)
			for (int j = 0 ; j < 4; j++)
				System.out.println(sample_d[i][j]);
		
		float[] a = {1 , 2 , 3, 4}; 
		float[] b = {1 , 3, 3 , 4}; 
		int c = Util.count_equivalance(a,b); 
		System.out.println(c);
		
		float[] col = Util.get_column(d, 1);
		System.err.println(col[0] + "," + col[1] + "," + col[2]);
	}
}
