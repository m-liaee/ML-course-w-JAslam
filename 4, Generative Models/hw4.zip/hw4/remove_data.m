function data = remove_data(data, indices)  
    data(indices,:) = [];  
end