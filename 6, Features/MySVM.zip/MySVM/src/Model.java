import java.lang.reflect.Array;
import java.util.ArrayList;


public class Model {
	ArrayList<Platt_SVM> platt_svms; 
	
	
	
	public Model() {
		platt_svms = new ArrayList<Platt_SVM>(); 
	 
	}
	
	
}
