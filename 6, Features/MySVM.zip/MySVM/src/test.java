
public class test {
	public static void main(String[] args) {
		
//		double [] arr = { 1 , 12 , 0 , 4 , 9};
//		System.out.println(Util.get_num_between_value(arr, 0, 9));
		
		double [][] arr = new double [6000][6000]; 
		 
		System.out.println(arr[10][10]);
	}
}
