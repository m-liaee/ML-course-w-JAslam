import java.util.ArrayList;


public class Feature_Values {

	ArrayList<Integer> values = new ArrayList<Integer>(); 
}
